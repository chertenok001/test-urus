$(function () {
  
  window.onscroll = function showHeader() {
    var header__top = document.querySelector(".header__top");
    if (window.pageYOffset > 0) {
      header__top.classList.add("header__fixed");
    } else {
      header__top.classList.remove("header__fixed");
    }
  };
 

  $('.reviews__slider').slick({
    dots:true,
    arrows:false

 
  });
  

});
var mixer = mixitup('.assortment__list');